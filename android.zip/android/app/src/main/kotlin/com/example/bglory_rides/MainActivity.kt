package com.example.bglory_rides

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
