import 'package:flutter/material.dart';

const TextStyle white500TextStyle = TextStyle(
  color: Colors.white,
  fontWeight: FontWeight.w500,
);
