// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'withdrawal_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$withdrawalStateNotifierHash() =>
    r'c0c04dcec10cff84ace20a697216e8ce890994eb';

/// See also [WithdrawalStateNotifier].
@ProviderFor(WithdrawalStateNotifier)
final withdrawalStateNotifierProvider = AutoDisposeNotifierProvider<
    WithdrawalStateNotifier, WithdrawalState>.internal(
  WithdrawalStateNotifier.new,
  name: r'withdrawalStateNotifierProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$withdrawalStateNotifierHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$WithdrawalStateNotifier = AutoDisposeNotifier<WithdrawalState>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
