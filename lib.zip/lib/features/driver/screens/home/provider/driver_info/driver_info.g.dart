// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'driver_info.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$driverInfoHash() => r'778e0aa66738dfadc37b63eab41a66e84fb8c284';

/// See also [DriverInfo].
@ProviderFor(DriverInfo)
final driverInfoProvider =
    NotifierProvider<DriverInfo, DriverInfoState>.internal(
  DriverInfo.new,
  name: r'driverInfoProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$driverInfoHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$DriverInfo = Notifier<DriverInfoState>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
