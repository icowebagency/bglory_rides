// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'successful_verification_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$successfulVerificationStateNotifierHash() =>
    r'9c78e85046a67c08ed6f4502253027b7c5330e29';

/// See also [SuccessfulVerificationStateNotifier].
@ProviderFor(SuccessfulVerificationStateNotifier)
final successfulVerificationStateNotifierProvider = AutoDisposeNotifierProvider<
    SuccessfulVerificationStateNotifier, bool>.internal(
  SuccessfulVerificationStateNotifier.new,
  name: r'successfulVerificationStateNotifierProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$successfulVerificationStateNotifierHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$SuccessfulVerificationStateNotifier = AutoDisposeNotifier<bool>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
