// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'driver_registration_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$registrationNotifierHash() =>
    r'4e7659bb13a3e0de99d2340fe798595d99562090';

/// See also [RegistrationNotifier].
@ProviderFor(RegistrationNotifier)
final registrationNotifierProvider =
    AutoDisposeNotifierProvider<RegistrationNotifier, bool>.internal(
  RegistrationNotifier.new,
  name: r'registrationNotifierProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$registrationNotifierHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$RegistrationNotifier = AutoDisposeNotifier<bool>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
