class ApiResponse {
  final String status;
  final String message;
  final dynamic data;

  const ApiResponse({
    required this.status,
    required this.message,
    required this.data,
  });

  factory ApiResponse.fromJson(Map<String, dynamic> json) => ApiResponse(
        status: json['status'] as String,
        message: json['message'] as String,
        data: json['data'],
      );
}
